# Third-party components

This application includes unmodified CPython, Qt for Python (PySide6/Shiboken),
NumPy, SciPy, Bleak, PyWinRT, pyserial and HTTP/Socket.IO dependencies.
Their notices and license texts are in licenses/. PyInstaller's distribution
exception applies to its bootloader; its COPYING text is included.

Qt for Python is used under LGPLv3. Qt and Shiboken DLLs remain separate in
_internal/ and may be replaced with compatible builds. Reverse engineering
for debugging modifications to LGPL components is permitted. Corresponding
upstream sources and build instructions:
https://code.qt.io/cgit/pyside/pyside-setup.git/
https://code.qt.io/cgit/qt/qtbase.git/
https://doc.qt.io/qtforpython-6/building_from_source/index.html
Use the tag matching the version listed below. This application does not
modify these libraries; its application/build sources are available at
https://github.com/COSMOnEsmer/UWBBoardProgrammer .

Compiled firmware and the included DK6 programming components target Murata
Type2BP/Type2DK EVKs using NXP QN9090/SR150/SR040 products. Use them only for
these NXP-based boards as an integrated part of this application. NXP EULAs
and Software Content Registers accompany the firmware in licenses/.
The raw vendor SDK archives and vendor source trees are not included.
The USB programming tools also include FTDI D2XX and GCC runtime components;
their original DLLs and notices are retained. FTDI drivers are supplied by
Windows Update or https://ftdichip.com/drivers/ .

Bundled Python component versions:

- PySide6==6.11.2
- PySide6_Addons==6.11.2
- PySide6_Essentials==6.11.2
- altgraph==0.17.5
- bidict==0.24.1
- bleak==3.0.1
- certifi==2026.10.23
- charset-normalizer==3.5.2
- colorama==0.4.6
- h11==0.16.0
- idna==3.20
- numpy==2.5.3
- packaging==26.3
- pefile==2024.8.26
- pyinstaller==6.22.3
- pyinstaller-hooks-contrib==2026.9
- pyserial==3.5
- python-engineio==4.15.1
- python-socketio==5.17.0
- pywin32-ctypes==0.2.3
- requests==2.34.2
- scipy==1.18.1
- shiboken6==6.11.2
- simple-websocket==1.1.0
- typing_extensions==4.16.0
- urllib3==2.8.0
- websocket-client==1.9.2
- winrt-Windows.Devices.Bluetooth==4!10.0.28000.2957
- winrt-Windows.Devices.Bluetooth.Advertisement==4!10.0.28000.2957
- winrt-Windows.Devices.Bluetooth.GenericAttributeProfile==4!10.0.28000.2957
- winrt-Windows.Devices.Enumeration==4!10.0.28000.2957
- winrt-Windows.Devices.Radios==4!10.0.28000.2957
- winrt-Windows.Foundation==4!10.0.28000.2957
- winrt-Windows.Foundation.Collections==4!10.0.28000.2957
- winrt-Windows.Storage.Streams==4!10.0.28000.2957
- winrt-runtime==4.1.0
- wsproto==1.3.2
