# Auto Survey development tasks

Status: development in progress. Existing 2.1.2 and firmware 1.3.4-pilot remain intact.

Requested result: estimate all four anchor coordinates, use a reference Tag as the origin,
preview uncertainty/quality, and save a NEW Survey profile for subsequent TDoA positioning.

## Measurement and coordinate contract

- A single stationary Tag's existing BLINK/TDoA reports do not determine unknown anchor XYZ.
- Add sequential DS-TWR measurements for the six anchor pairs and four Tag-to-anchor pairs.
- Range-derived geometry has an arbitrary rotation/reflection. A Tag origin alone does not make Z physical height.
- The wizard will capture origin, +X direction, and a second non-collinear point at the same reference height to define the XY plane and right-handed +Z. No claimed compass/gravity orientation is inferred from uncalibrated AoA.
- The calibration phase may keep the Tag connected by USB. The normal battery/BLINK image remains available for operation after calibration. Do not silently replace battery mode with an always-awake ranging image.
- Radio commands have request IDs, peer/session binding, expiry and automatic return to standalone operation. Capture does not publish RTLS positions.
- Unknown antenna/timing delays cannot be jointly determined from one static range graph. Require independent known-distance and holdout reference checks before accepting an accurate survey; fit residual alone is insufficient.

## Tasks

1. Inspect vendor TWR APIs, Murata calibration requirements, and current hardware identities.
2. Implement a separate range protocol and dual TDoA/TWR anchor firmware with BLE control; add an explicit Tag calibration image/workflow.
3. Build experimental images in fresh SDK copies. Back up and identify connected boards before any Flash.
4. Demonstrate real TWR on the connected Anchor/Tag pair and verify return to standalone TDoA.
5. Implement range aggregation, robust geometry recovery, degeneracy checks and coordinate-frame registration, with tests for non-identifiable inputs and reflection.
6. Add an Auto Survey wizard to a NEW full-app revision, including capture progress, preview, limitations and save-new-profile behavior.
7. Test the BLE command/capture workflow, loss/timeout restoration and English/Thai UI. No fabricated RF measurements or automatic survey confirmation.
8. Package a portable app/firmware bundle, preserve previous releases and shortcuts, and push the reviewed additions to GitHub.

Full four-anchor RF acceptance needs the four anchors to run the new firmware and independent reference measurements. Do not mark this work hardware-validated from simulated geometry tests or a single pair test.
